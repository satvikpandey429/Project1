const API = "http://127.0.0.1:8000";

let state = {
    domain: null,
    category: null,
    document: null,
    questions: [],
    answers: {},
    content: null,
    pdfFile: null,
    docxFile: null
};

// Make all functions globally accessible
window.loadDomains = loadDomains;
window.selectDomain = selectDomain;
window.loadDocuments = loadDocuments;
window.generateDocument = generateDocument;
window.downloadOriginalPDF = downloadOriginalPDF;
window.downloadOriginalDOCX = downloadOriginalDOCX;
window.downloadEditedPDF = downloadEditedPDF;
window.downloadEditedDOCX = downloadEditedDOCX;

// Load domains on page load
window.onload = function() {
    console.log('Page loaded, initializing...');
    loadDomains();
    
    // Test if generateQuestions is accessible
    console.log('generateQuestions function:', typeof window.generateQuestions);
};

// Load domains
async function loadDomains() {
    const grid = document.getElementById('domainGrid');
    grid.innerHTML = '<div class="loading">Loading domains...</div>';
    
    try {
        const res = await fetch(`${API}/domains/`);
        const data = await res.json();
        const domains = data.domains || ['Family Law', 'Contract Law', 'Intellectual Property Law'];
        
        grid.innerHTML = '';
        domains.forEach(domain => {
            const card = document.createElement('div');
            card.className = 'card';
            card.onclick = () => selectDomain(domain);
            card.innerHTML = `<div style="font-size: 28px; margin-bottom: 8px;">${getIcon(domain)}</div><div><strong>${domain}</strong></div>`;
            grid.appendChild(card);
        });
    } catch (err) {
        grid.innerHTML = '<div class="error">Error: Backend not running. Start backend server first.</div>';
    }
}

function getIcon(domain) {
    const icons = {
        'Family Law': '👨‍👩‍👧‍👦',
        'Contract Law': '📋',
        'Intellectual Property Law': '🔐'
    };
    return icons[domain] || '⚖️';
}

// Select domain
async function selectDomain(domain) {
    state.domain = domain;
    
    try {
        const res = await fetch(`${API}/categories/?domain=${encodeURIComponent(domain)}`);
        const data = await res.json();
        const select = document.getElementById('categorySelect');
        select.innerHTML = '<option value="">Select Category</option>';
        data.categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat;
            opt.textContent = cat;
            select.appendChild(opt);
        });
        document.getElementById('documentSelect').innerHTML = '<option value="">Select Document</option>';
    } catch (err) {
        alert('Error loading categories: ' + err.message);
    }
}

// Load documents
async function loadDocuments() {
    const category = document.getElementById('categorySelect').value;
    if (!state.domain || !category) return;
    
    state.category = category;
    
    try {
        const res = await fetch(`${API}/documents/?domain=${encodeURIComponent(state.domain)}&category=${encodeURIComponent(category)}`);
        const data = await res.json();
        const select = document.getElementById('documentSelect');
        select.innerHTML = '<option value="">Select Document</option>';
        data.documents.forEach(doc => {
            const opt = document.createElement('option');
            opt.value = doc;
            opt.textContent = doc;
            select.appendChild(opt);
        });
    } catch (err) {
        alert('Error loading documents: ' + err.message);
    }
}

// Generate questions - Make it globally accessible
window.generateQuestions = async function generateQuestions() {
    console.log('=== GENERATE QUESTIONS CLICKED ===');
    
    const categoryEl = document.getElementById('categorySelect');
    const documentEl = document.getElementById('documentSelect');
    
    if (!categoryEl || !documentEl) {
        console.error('Select elements not found!');
        alert('Form elements not found. Please refresh the page.');
        return;
    }
    
    const category = categoryEl.value;
    const document = documentEl.value;
    
    console.log('Selected values:', { category, document, domain: state.domain });
    
    if (!category || !document) {
        alert('Please select both category and document');
        return;
    }
    
    if (!state.domain) {
        alert('Please select a domain first');
        return;
    }
    
    state.category = category;
    state.document = document;
    state.answers = {};
    
    const container = document.getElementById('questionsContainer');
    if (!container) {
        console.error('questionsContainer not found!');
        alert('Questions container not found. Please refresh the page.');
        return;
    }
    
    console.log('Showing loading message...');
    container.innerHTML = '<div class="loading">Generating questions...</div>';
    
    const requestData = { domain: state.domain, category, document };
    console.log('Sending request to:', `${API}/ai/questions`);
    console.log('Request data:', requestData);
    
    try {
        const res = await fetch(`${API}/ai/questions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestData)
        });
        
        console.log('Response status:', res.status);
        console.log('Response ok:', res.ok);
        
        if (!res.ok) {
            let errorDetail = 'Failed to generate questions';
            try {
                const errorData = await res.json();
                errorDetail = errorData.detail || JSON.stringify(errorData);
                console.error('Error response:', errorData);
            } catch (e) {
                const errorText = await res.text();
                errorDetail = errorText || `HTTP ${res.status}`;
                console.error('Error text:', errorText);
            }
            throw new Error(errorDetail);
        }
        
        const data = await res.json();
        console.log('Response data:', data);
        
        if (!data.questions) {
            console.error('No questions field in response:', data);
            throw new Error('Invalid response: No questions field');
        }
        
        if (!Array.isArray(data.questions) || data.questions.length === 0) {
            console.error('Empty or invalid questions array:', data.questions);
            throw new Error('No questions received from server');
        }
        
        console.log('Questions received:', data.questions.length);
        state.questions = data.questions;
        
        container.innerHTML = '';
        data.questions.forEach((q, idx) => {
            const item = document.createElement('div');
            item.className = 'question-item';
            
            const label = document.createElement('label');
            label.textContent = `${idx + 1}. ${q}`;
            
            const textarea = document.createElement('textarea');
            textarea.placeholder = 'Enter your answer...';
            textarea.oninput = function() {
                state.answers[q] = this.value;
            };
            
            item.appendChild(label);
            item.appendChild(textarea);
            container.appendChild(item);
        });
        
        console.log('Questions displayed successfully!');
    } catch (err) {
        console.error('Error in generateQuestions:', err);
        container.innerHTML = `<div class="error">Error: ${err.message}<br><br>Check browser console (F12) for details.</div>`;
        alert(`Error: ${err.message}\n\nPlease check:\n1. Backend is running on ${API}\n2. OPENAI_API_KEY is set\n3. Open browser console (F12) for details`);
    }
};

// Generate document
async function generateDocument() {
    const btn = document.getElementById('generateBtn');
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Generating...';
    }
    
    try {
        const res = await fetch(`${API}/ai/generate-pdf`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                domain: state.domain,
                category: state.category,
                document: state.document,
                answers: state.answers
            })
        });
        
        if (!res.ok) {
            const error = await res.json().catch(() => ({ detail: 'Failed to generate document' }));
            throw new Error(error.detail || 'Failed to generate document');
        }
        
        const data = await res.json();
        
        state.content = data.content;
        state.pdfFile = data.file;
        state.docxFile = data.docx_file;
        
        const editor = document.getElementById('documentEditor');
        if (editor) {
            editor.value = data.content;
        }
    } catch (err) {
        alert('Error: ' + err.message);
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = 'Generate Document';
        }
    }
}

// Download functions
function downloadOriginalPDF() {
    if (!state.pdfFile) {
        alert('PDF not available');
        return;
    }
    window.open(`${API}/generated_documents/${state.pdfFile}`, '_blank');
}

function downloadOriginalDOCX() {
    if (!state.docxFile) {
        alert('DOCX not available');
        return;
    }
    window.open(`${API}/generated_documents/${state.docxFile}`, '_blank');
}

async function downloadEditedPDF() {
    const content = document.getElementById('documentEditor').value;
    if (!content) {
        alert('No content to download');
        return;
    }
    
    try {
        const filename = state.pdfFile ? state.pdfFile.replace('.pdf', '_edited.pdf') : 'edited.pdf';
        const res = await fetch(`${API}/ai/generate-pdf-from-content`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content, filename })
        });
        
        if (!res.ok) throw new Error('Failed to generate PDF');
        
        const data = await res.json();
        window.open(`${API}${data.download_url}`, '_blank');
    } catch (err) {
        alert('Error: ' + err.message);
    }
}

async function downloadEditedDOCX() {
    const content = document.getElementById('documentEditor').value;
    if (!content) {
        alert('No content to download');
        return;
    }
    
    try {
        const filename = state.docxFile ? state.docxFile.replace('.docx', '_edited.docx') : 'edited.docx';
        const res = await fetch(`${API}/ai/generate-docx-from-content`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content, filename })
        });
        
        if (!res.ok) throw new Error('Failed to generate DOCX');
        
        const data = await res.json();
        window.open(`${API}${data.download_url}`, '_blank');
    } catch (err) {
        alert('Error: ' + err.message);
    }
}
