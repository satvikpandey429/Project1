from app.prompts import family_law, contract_law, ipr_law

# Map domain names to their prompt dictionaries
PROMPT_REGISTRY = {
    "Family Law": family_law.FAMILY_LAW_PROMPTS,
    "Contract Law": contract_law.CONTRACT_LAW_PROMPTS,
    "Intellectual Property Law": ipr_law.IPR_LAW_PROMPTS
}

def get_prompt(domain: str, category: str, document: str) -> str:
    """
    Get the prompt for a specific domain, category, and document.
    Returns the prompt string or None if not found.
    """
    domain_prompts = PROMPT_REGISTRY.get(domain)
    if not domain_prompts:
        return None
    
    # For Family Law, structure is: category -> document -> prompt
    if domain == "Family Law":
        category_prompts = domain_prompts.get(category)
        if category_prompts:
            doc_info = category_prompts.get(document)
            if doc_info:
                return doc_info.get("prompt")
    
    # For Contract Law, structure is: document -> company_type -> {category, prompt}
    # We need to find the document and match by category field
    elif domain == "Contract Law":
        doc_prompts = domain_prompts.get(document)
        if doc_prompts:
            # Find entry where category matches
            for company_type, info in doc_prompts.items():
                if isinstance(info, dict) and info.get("category") == category:
                    return info.get("prompt")
            # Fallback: return first available prompt
            for company_type, info in doc_prompts.items():
                if isinstance(info, dict) and "prompt" in info:
                    return info.get("prompt")
    
    # For IPR Law, structure is: category -> document -> prompt
    elif domain == "Intellectual Property Law":
        category_prompts = domain_prompts.get(category)
        if category_prompts:
            doc_info = category_prompts.get(document)
            if doc_info:
                return doc_info.get("prompt")
    
    return None
