from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
import os

def sanitize_text(text: str) -> str:
    return (
        text
        .replace("'", "'")
        .replace(""", '"')
        .replace(""", '"')
        .replace("–", "-")
        .replace("—", "-")
    )

def generate_docx(content: str, filename: str = None):
    """
    Generate a DOCX file from content.
    """
    doc = Document()
    
    # Set default font
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(12)
    
    # Add content
    safe_content = sanitize_text(content)
    
    # Split content into paragraphs and add them
    paragraphs = safe_content.split('\n\n')
    for para_text in paragraphs:
        if para_text.strip():
            para = doc.add_paragraph(para_text.strip())
            para_format = para.paragraph_format
            para_format.space_after = Pt(6)
    
    # Save document
    os.makedirs("generated_documents", exist_ok=True)
    if filename:
        path = f"generated_documents/{filename}"
    else:
        path = "generated_documents/legal_document.docx"
    
    doc.save(path)
    return path

