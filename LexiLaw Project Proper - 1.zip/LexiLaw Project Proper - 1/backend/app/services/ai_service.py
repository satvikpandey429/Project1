import os
from openai import OpenAI
from dotenv import load_dotenv
from app.prompt_registry import get_prompt

# Load environment variables from .env file
load_dotenv()

# Initialize client lazily
_client = None

def get_client():
    """Get OpenAI client, initializing it if needed."""
    global _client
    if _client is None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable is not set. Please create a .env file in the backend directory with OPENAI_API_KEY=your_key")
        _client = OpenAI(api_key=api_key)
    return _client

def generate_questions(domain: str, category: str, document: str):
    """
    Generate questions for a specific legal document.
    Uses OpenAI to generate relevant questions based on domain, category, and document type.
    """
    prompt = f"""You are a legal assistant specializing in {domain} in India.
Generate a numbered list of clear, specific questions required to draft a {document} under {category} in {domain}.
Return only the questions, one per line, numbered.
Make sure the questions are relevant to Indian law and the specific document type."""

    try:
        client = get_client()
        res = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7
        )

        text = res.choices[0].message.content
        # Parse questions from the response
        questions = []
        for line in text.split("\n"):
            line = line.strip()
            if line:
                # Remove numbering (1., 2., etc.) and bullet points
                cleaned = line.lstrip("0123456789.-) ").strip()
                if cleaned:
                    questions.append(cleaned)
        
        return questions if questions else ["Please provide relevant details for this document."]
    except Exception as e:
        print(f"Error generating questions: {e}")
        return ["Please provide relevant details for this document."]

def generate_document(domain: str, category: str, document: str, answers: dict):
    """
    Generate a legal document using the prompt registry and user answers.
    """
    # Get the specific prompt from registry
    base_prompt = get_prompt(domain, category, document)
    
    # Format user answers
    formatted_answers = "\n".join(
        [f"{k}: {v}" for k, v in answers.items() if v.strip()]
    )
    
    # Build the final prompt
    if base_prompt:
        prompt = f"""{base_prompt}

User Provided Information:
{formatted_answers}

Please draft the complete document based on the above information. Ensure it is professional, legally compliant, and formatted properly."""
    else:
        # Fallback prompt if not found in registry
        prompt = f"""You are a legal assistant with 20+ years of experience in {domain} in India.
Draft a professional {document} under {category} in {domain}.

User Provided Information:
{formatted_answers}

Ensure the document is legally compliant, uses proper legal language, and follows Indian law requirements."""

    try:
        client = get_client()
        res = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=2000
        )

        return res.choices[0].message.content
    except Exception as e:
        print(f"Error generating document: {e}")
        raise Exception(f"Failed to generate document: {str(e)}")

