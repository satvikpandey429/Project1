from fpdf import FPDF
import os

def sanitize_text(text: str) -> str:
    return (
        text
        .replace("’", "'")
        .replace("“", '"')
        .replace("”", '"')
        .replace("–", "-")
        .replace("—", "-")
    )

def generate_pdf(content: str, filename: str = None):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    safe_content = sanitize_text(content)

    pdf.multi_cell(0, 8, safe_content)

    os.makedirs("generated_documents", exist_ok=True)
    if filename:
        path = f"generated_documents/{filename}"
    else:
        path = "generated_documents/legal_document.pdf"
    pdf.output(path)

    return path
