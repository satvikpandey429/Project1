from fastapi import APIRouter, Query
from app.prompt_registry import PROMPT_REGISTRY

router = APIRouter(prefix="/categories", tags=["Categories"])

def get_categories_from_registry(domain: str):
    """
    Extract categories from prompt registry based on domain.
    """
    domain_prompts = PROMPT_REGISTRY.get(domain)
    if not domain_prompts:
        return []
    
    categories = []
    
    # Family Law structure: category -> document
    if domain == "Family Law":
        categories = list(domain_prompts.keys())
    
    # Contract Law structure: document -> company_type -> {category, prompt}
    elif domain == "Contract Law":
        # Extract unique categories from all documents
        category_set = set()
        for doc_data in domain_prompts.values():
            if isinstance(doc_data, dict):
                for company_type, cat_info in doc_data.items():
                    if isinstance(cat_info, dict) and "category" in cat_info:
                        category_set.add(cat_info["category"])
        categories = sorted(list(category_set))
    
    # IPR Law structure: category -> document
    elif domain == "Intellectual Property Law":
        categories = list(domain_prompts.keys())
    
    return categories

@router.get("/")
def get_categories(domain: str = Query(...)):
    categories = get_categories_from_registry(domain)
    return {"categories": categories}


