from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict
from app.services import ai_service
from app.services import pdf_service
from app.services import docx_service

router = APIRouter(prefix="/ai", tags=["AI"])

class QuestionRequest(BaseModel):
    domain: str
    category: str
    document: str

class GenerateRequest(BaseModel):
    domain: str
    category: str
    document: str
    answers: Dict[str, str]

@router.post("/questions")
def get_questions(req: QuestionRequest):
    """
    Generate questions for a specific legal document using OpenAI.
    """
    try:
        questions = ai_service.generate_questions(
            domain=req.domain,
            category=req.category,
            document=req.document
        )
        return {"questions": questions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating questions: {str(e)}")

@router.post("/generate-pdf")
def generate_pdf(req: GenerateRequest):
    """
    Generate a legal document using OpenAI and convert it to PDF.
    """
    try:
        # Generate document content using AI
        document_content = ai_service.generate_document(
            domain=req.domain,
            category=req.category,
            document=req.document,
            answers=req.answers
        )
        
        # Generate PDF from content
        pdf_path = pdf_service.generate_pdf(document_content)
        
        # Generate DOCX as well
        docx_filename = pdf_path.replace('.pdf', '.docx')
        docx_path = docx_service.generate_docx(document_content, docx_filename.split('/')[-1] if '/' in docx_filename else docx_filename.split('\\')[-1])
        
        # Return the filename (relative path)
        filename = pdf_path.split("/")[-1] if "/" in pdf_path else pdf_path.split("\\")[-1]
        download_url = f"/generated_documents/{filename}"
        docx_filename_only = docx_path.split("/")[-1] if "/" in docx_path else docx_path.split("\\")[-1]
        docx_download_url = f"/generated_documents/{docx_filename_only}"
        
        return {
            "file": filename,
            "path": pdf_path,
            "download_url": download_url,
            "docx_file": docx_filename_only,
            "docx_download_url": docx_download_url,
            "content": document_content  # Also return content for preview
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating PDF: {str(e)}")

@router.post("/generate-docx")
def generate_docx_endpoint(req: GenerateRequest):
    """
    Generate a DOCX file from content (for edited documents).
    """
    try:
        # This endpoint will be used for generating DOCX from edited content
        # For now, we'll accept content directly
        pass
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating DOCX: {str(e)}")

class GenerateDocxRequest(BaseModel):
    content: str
    filename: str = "legal_document.docx"

class GeneratePdfRequest(BaseModel):
    content: str
    filename: str = "legal_document.pdf"

@router.post("/generate-docx-from-content")
def generate_docx_from_content(req: GenerateDocxRequest):
    """
    Generate a DOCX file from provided content (for edited documents).
    """
    try:
        docx_path = docx_service.generate_docx(req.content, req.filename)
        filename = docx_path.split("/")[-1] if "/" in docx_path else docx_path.split("\\")[-1]
        download_url = f"/generated_documents/{filename}"
        
        return {
            "file": filename,
            "path": docx_path,
            "download_url": download_url
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating DOCX: {str(e)}")

@router.post("/generate-pdf-from-content")
def generate_pdf_from_content(req: GeneratePdfRequest):
    """
    Generate a PDF file from provided content (for edited documents).
    """
    try:
        pdf_path = pdf_service.generate_pdf(req.content, req.filename)
        filename = pdf_path.split("/")[-1] if "/" in pdf_path else pdf_path.split("\\")[-1]
        download_url = f"/generated_documents/{filename}"
        
        return {
            "file": filename,
            "path": pdf_path,
            "download_url": download_url
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating PDF: {str(e)}")
