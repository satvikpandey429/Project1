from fastapi import APIRouter, Query
from app.prompt_registry import PROMPT_REGISTRY

router = APIRouter(prefix="/documents", tags=["Documents"])

def get_documents_from_registry(domain: str, category: str):
    """
    Extract document list from prompt registry based on domain and category.
    """
    domain_prompts = PROMPT_REGISTRY.get(domain)
    if not domain_prompts:
        return []
    
    documents = []
    
    # Family Law structure: category -> document
    if domain == "Family Law":
        category_prompts = domain_prompts.get(category)
        if category_prompts:
            documents = list(category_prompts.keys())
    
    # Contract Law structure: document -> company_type -> {category, prompt}
    elif domain == "Contract Law":
        # For Contract Law, we need to match documents by their category field
        for doc_name, doc_data in domain_prompts.items():
            if isinstance(doc_data, dict):
                # Check if any entry in this document has the matching category
                for company_type, cat_info in doc_data.items():
                    if isinstance(cat_info, dict) and cat_info.get("category") == category:
                        if doc_name not in documents:
                            documents.append(doc_name)
                        break
    
    # IPR Law structure: category -> document
    elif domain == "Intellectual Property Law":
        category_prompts = domain_prompts.get(category)
        if category_prompts:
            documents = list(category_prompts.keys())
    
    return documents

@router.get("/")
def get_documents(domain: str = Query(...), category: str = Query(...)):
    documents = get_documents_from_registry(domain, category)
    return {"documents": documents}

