from fastapi import APIRouter

router = APIRouter(prefix="/domains", tags=["Domains"])

DOMAINS = [
    "Family Law",
    "Contract Law",
    "Intellectual Property Law"
]

@router.get("/")
def get_domains():
    return {"domains": DOMAINS}

