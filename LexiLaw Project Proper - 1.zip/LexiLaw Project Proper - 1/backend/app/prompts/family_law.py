FAMILY_LAW_PROMPTS = {

    "Hindu Law": {

        "Marriage Certificate Petition": {
            "category": "Marriage",
            "religion": "Hindu",
            "prompt": """You are a Family Law Advocate with 20+ years of experience.
Draft a Hindu Marriage Petition for issuance of a marriage certificate in India,
ensuring all necessary details as per jurisdictional requirements.
Show the petition on screen and provide option to store in MS-Word document format."""
        },

        "Mutual Consent Divorce Petition": {
            "category": "Divorce",
            "religion": "Hindu",
            "prompt": """You are a Family Law Advocate with 20+ years of experience.
Draft a Hindu Mutual Consent Divorce Petition in India.
Ensure compliance with Hindu Marriage Act.
Show the petition on screen and give option to store in MS-Word document."""
        },

        "Contested Divorce Petition (Wife)": {
            "category": "Divorce",
            "religion": "Hindu",
            "prompt": """Draft a Hindu Contested Divorce Petition filed by Wife.
Ensure grounds, jurisdiction, reliefs and compliance with Hindu Marriage Act."""
        },

        "Contested Divorce Petition (Husband)": {
            "category": "Divorce",
            "religion": "Hindu",
            "prompt": """Draft a Hindu Contested Divorce Petition filed by Husband.
Ensure legal grounds, pleadings and reliefs."""
        },

        "Child Custody Petition": {
            "category": "Child Custody",
            "religion": "Hindu",
            "prompt": """Draft a Petition for Minor Child Custody under Hindu Personal Laws."""
        },

        "Adoption Petition": {
            "category": "Adoption",
            "religion": "Hindu",
            "prompt": """Draft a Petition for Legal Adoption under Hindu Personal Laws."""
        },

        "Maintenance Application": {
            "category": "Maintenance",
            "religion": "Hindu",
            "prompt": """Draft an Application for Maintenance under Hindu Personal Laws."""
        },

        "Will & Property Distribution": {
            "category": "Inheritance",
            "religion": "Hindu",
            "prompt": """Draft a Will and Declaration of Property Distribution under Hindu Law."""
        }
    },

    "Christian Law": {

        "Marriage Certificate Petition": {
            "category": "Marriage",
            "religion": "Christian",
            "prompt": """Draft a Christian Marriage Petition for issuance of marriage certificate in India."""
        },

        "Mutual Consent Divorce Petition": {
            "category": "Divorce",
            "religion": "Christian",
            "prompt": """Draft a Christian Mutual Consent Divorce Petition."""
        },

        "Contested Divorce Petition (Wife)": {
            "category": "Divorce",
            "religion": "Christian",
            "prompt": """Draft a Christian Contested Divorce Petition filed by Wife."""
        },

        "Contested Divorce Petition (Husband)": {
            "category": "Divorce",
            "religion": "Christian",
            "prompt": """Draft a Christian Contested Divorce Petition filed by Husband."""
        },

        "Child Custody Petition": {
            "category": "Child Custody",
            "religion": "Christian",
            "prompt": """Draft a Petition for Minor Child Custody under Christian Personal Laws."""
        },

        "Maintenance Application": {
            "category": "Maintenance",
            "religion": "Christian",
            "prompt": """Draft an Application for Maintenance under Christian Personal Laws."""
        },

        "Will & Testament": {
            "category": "Inheritance",
            "religion": "Christian",
            "prompt": """Draft a Christian Will & Testament."""
        }
    }
}


