IPR_LAW_PROMPTS = {

    "Design Law": {

        "Design Registration Form & Statement": {
            "category": "Forms & Statements",
            "prompt": """You are a Design IPR Attorney in India with 20+ years experience.
Draft Form 1 and Statement of Novelty for Design Registration.
Make it a generic template and show on screen before storing in MS-Word."""
        },

        "Design Infringement Legal Notice": {
            "category": "Legal Notice",
            "prompt": """Draft a Design Infringement Legal Notice in India
including description, infringement details, legal basis and remedies."""
        },

        "Cease and Desist Notice": {
            "category": "Notice",
            "prompt": """Draft a Cease and Desist Notice for unauthorized use of a registered design."""
        },

        "Response to Novelty Objection": {
            "category": "Response",
            "prompt": """Draft a response to design objection claiming lack of novelty."""
        }
    },

    "Trademark Law": {

        "Trademark Application Drafting": {
            "category": "Application",
            "prompt": """Draft a Trademark Application for registration in India."""
        },

        "Trademark Search & Clearance": {
            "category": "Search",
            "prompt": """Perform Trademark Search & Clearance in India and provide analysis."""
        },

        "Trademark Infringement Notice": {
            "category": "Notice",
            "prompt": """Analyze trademark infringement and passing off under Indian law."""
        },

        "Reply to Examination Report": {
            "category": "Response",
            "prompt": """Draft a reply to Trademark Examination Report."""
        }
    },

    "Copyright Law": {

        "Copyright Registration Guidance": {
            "category": "Forms",
            "prompt": """Provide instructions for Copyright Registration in India."""
        },

        "Copyright Infringement Report": {
            "category": "Notice",
            "prompt": """Prepare a Copyright Infringement Report."""
        }
    },

    "Patent Law": {

        "Patent Specification Drafting": {
            "category": "Filing",
            "prompt": """Prepare a Patent Specification Report."""
        },

        "Patent Assessment Report": {
            "category": "Assessment",
            "prompt": """Prepare a Patentability Assessment Report for India."""
        }
    }
}
