CONTRACT_LAW_PROMPTS = {

    "Professional Services Agreement": {

        "Software / IT Company": {
            "category": "Agreement",
            "prompt": """Draft a Professional Service Agreement for software development / IT consulting company in India."""
        }
    },

    "Loan Agreement": {

        "IT Services Private Limited": {
            "category": "Finance",
            "prompt": """Draft a Loan Agreement compliant with Indian Contract Act and RBI Guidelines."""
        }
    },

    "Pledge Agreement": {

        "Software Company": {
            "category": "Security",
            "prompt": """Draft a Pledge Agreement for securing loan using shares or software IP."""
        }
    },

    "Personal Guarantee Agreement": {

        "Software Company": {
            "category": "Guarantee",
            "prompt": """Draft a Personal Guarantee Agreement between creditor, borrower and surety."""
        }
    },

    "Indemnity Agreement": {

        "Software Development Company": {
            "category": "Risk & Liability",
            "prompt": """Draft an Indemnity Agreement between software company and customer."""
        }
    }
}
