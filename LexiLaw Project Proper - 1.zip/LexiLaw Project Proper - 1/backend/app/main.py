from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.routes import domain_routes, categories, document_routes, ai_routes

app = FastAPI()

# Enable CORS for localhost
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # for local testing
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(domain_routes.router)
app.include_router(categories.router)
app.include_router(document_routes.router)
app.include_router(ai_routes.router)

# Serve generated PDFs statically
app.mount("/generated_documents", StaticFiles(directory="generated_documents"), name="generated_documents")

