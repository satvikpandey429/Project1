from pydantic import BaseModel
from typing import Dict

class QuestionRequest(BaseModel):
    domain: str
    document: str

class GenerateRequest(BaseModel):
    domain: str
    document: str
    answers: Dict[str, str]




